#!/bin/bash
./mkjar.bash &&\
java -jar jar/client.jar $1 $2
