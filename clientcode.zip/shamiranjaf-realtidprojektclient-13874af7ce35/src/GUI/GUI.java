package GUI;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import client.ClientStateMonitor;
import client.ImageWrapper;
import client.WriteThread;
// To gain access to maximum image size
import se.lth.cs.eda040.fakecamera.AxisM3006V;

class ImagePanel extends JPanel {
    ImageIcon icon;
    
    public ImagePanel() {
        super();
        icon = new ImageIcon();
        JLabel label = new JLabel(icon);
        add(label, BorderLayout.CENTER);
        this.setPreferredSize(new Dimension(640,520));
    }

    public void refresh(byte[] data) {
        Image theImage = getToolkit().createImage(data);
        getToolkit().prepareImage(theImage, -1, -1, null);
        icon.setImage(theImage);
        icon.paintIcon(this, this.getGraphics(), 5, 5);
    }
}

class TextPanel extends JPanel {
    JTextArea delayText;
    String who;
    public final static String no_set_movie = "Activated Movie: false";
    public final static String set_movie = "Activated Movie: true";
    public TextPanel() {
        super();

        who = no_set_movie;
        delayText = new JTextArea("No images yet!");
        add(delayText, BorderLayout.CENTER);
        //this.setPrefferedSize(new Dimension(100, 30));
    }

    public void refresh(String text) {
        delayText.setText(text + "  " + who);
    }

    public void setWho(boolean set) {
        this.who = set? set_movie : no_set_movie;
    }
    
}

public class GUI extends JFrame {

    private ImagePanel imagePanel1;
    private ImagePanel imagePanel2;
    private TextPanel textPanel1;
    private TextPanel textPanel2;
    private boolean firstCall = true;
    private byte[] jpeg = new byte[AxisM3006V.IMAGE_BUFFER_SIZE];
    private ClientStateMonitor stateMonitor;
    private JRadioButton movieButton;
    public GUI(ClientStateMonitor stateMonitor) {
        super();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        imagePanel1 = new ImagePanel();
        imagePanel2 = new ImagePanel();
        textPanel1 = new TextPanel();
        textPanel2 = new TextPanel();
        this.setSize(500, 500);
        this.getContentPane().setLayout(new BorderLayout());
        this.stateMonitor = stateMonitor;

        JPanel imageContainer1 = new JPanel(new BorderLayout());
        JPanel imageContainer2 = new JPanel(new BorderLayout());
        // Change button to imagePanel
        // JButton imageButton1 = new JButton("Image1");
        // JButton imageButton2 = new JButton("Image2");
        // imageButton1.setPreferredSize(new Dimension(400,400));
        // imageButton2.setPreferredSize(new Dimension(400, 400));
        imageContainer1.add(imagePanel1, BorderLayout.PAGE_START);
        imageContainer1.add(textPanel1, BorderLayout.PAGE_END);
        imageContainer2.add(imagePanel2, BorderLayout.PAGE_START);
        imageContainer2.add(textPanel2, BorderLayout.PAGE_END);
       // imageContainer1.add(new JTextArea("Delay 0.5"), BorderLayout.PAGE_END);
       // imageContainer2.add(new JTextArea("Delay 1"), BorderLayout.PAGE_END);
        JRadioButton autoButton = new JRadioButton("Auto");
        JRadioButton idleButton = new JRadioButton("Idle");
        movieButton = new JRadioButton("Movie");

        JPanel buttonContainer = new JPanel(new BorderLayout());
        ButtonGroup controls = new ButtonGroup();
        controls.add(autoButton);
        controls.add(idleButton);
        controls.add(movieButton);

        buttonContainer.add(autoButton, BorderLayout.NORTH);
        buttonContainer.add(idleButton, BorderLayout.CENTER);
        buttonContainer.add(movieButton, BorderLayout.SOUTH);
        autoButton.setSelected(true);

        autoButton.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                stateMonitor.setMode(ClientStateMonitor.AUTO, 0);
                }
                });

        idleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stateMonitor.setMode(ClientStateMonitor.IDLE, 0);
            }
        });

        movieButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                stateMonitor.setMode(ClientStateMonitor.MOVIE, 0);
                }
                });

        // imageContainer.add(delay1, BorderLayout.SOUTH);
        this.getContentPane().add(imageContainer1, BorderLayout.WEST);
        this.getContentPane().add(imageContainer2, BorderLayout.EAST);
        // this.getContentPane().add(imagePanel, BorderLayout.NORTH);

        this.getContentPane().add(buttonContainer, BorderLayout.SOUTH);
        // this.getContentPane().add(autoButton, BorderLayout.SOUTH);
        // this.getContentPane().add(idleButton, BorderLayout.SOUTH);
        // this.getContentPane().add(movieButton, BorderLayout.SOUTH);
        this.setLocationRelativeTo(null);
        this.pack();
        this.setVisible(true);
    }

    public void refreshImage(ImageWrapper imageWrapper) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if(imageWrapper.getCameraId() == 1){
                    imagePanel1.refresh(imageWrapper.getImageData());
                    textPanel1.refresh(getDelayString(imageWrapper.getTimeStamp())); 
                }else{
                    imagePanel2.refresh(imageWrapper.getImageData());
                    textPanel2.refresh(getDelayString(imageWrapper.getTimeStamp())); 
                }
            }
         });
    }

    public String getDelayString(long time) {
        long diff = System.currentTimeMillis() - time;
        float frac = diff/1000.0f;
        return "Delay: " + String.format("%.3f", frac);
    }

    public void setMovieMode() {
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                movieButton.setSelected(true);
                }
                });
    }

    public void setWhoSetMovie(int who) {
        if (who == 1) {
            textPanel1.setWho(true);
            textPanel2.setWho(false);
        } else if (who == 2) {
            textPanel1.setWho(false);
            textPanel2.setWho(true);
        } else {
            textPanel1.setWho(false);
            textPanel2.setWho(false);
        }
    }
}
