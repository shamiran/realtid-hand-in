package client;

import java.beans.Statement;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class ReadThread extends Thread {
    private Socket socket;
    private InputStream is;
    private BufferMonitor bufferMonitor;
    private int cameraId;
    private ClientStateMonitor stateMonitor;

    public ReadThread(Socket socket, BufferMonitor bm, int cameraId, ClientStateMonitor sm) {
        this.socket = socket;
        this.bufferMonitor = bm;
        this.cameraId = cameraId;
        try {
            this.is = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.stateMonitor = sm;
    }

    public void run() {
        System.out.println("Started Read thread: " + cameraId);
        while (true) {
            try {

                int type = is.read();
                if (type == 2) {
                    if (stateMonitor.getMode() == ClientStateMonitor.AUTO) {
                        stateMonitor.setMode(ClientStateMonitor.MOVIE, cameraId);
                    }
                }else if (type == 1) {
                    long size = 0;
                    for (int i = 3; i >= 0; i--) {// calculating size
                        long temp = is.read();
                        size = size + (temp << (8 * i));
                    }

                    long timeStamp = 0;
                    for (int i = 7; i >= 0; i--) {// calculating timestamp
                        timeStamp = timeStamp + ((long) is.read() << (8L * i));
                    }
                    // Discard timestamp from server and create new one from
                    // client system time
                    timeStamp /= 1000000L;

                    byte[] imageData = new byte[(int) size];
                    for (int i = 0; i < size; i++) {

                        imageData[i] = (byte) is.read();
                    }
                    // Image data

                    ImageWrapper image = new ImageWrapper(size, timeStamp, imageData, cameraId);
                    bufferMonitor.sendToBuffer(image);
                }

                // Movie mode command

                // if (is.read()==-1) {
                // System.out.println("Connection ended");
                // break;
                // }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

}
