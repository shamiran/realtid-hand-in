package client;

import GUI.GUI;

public class Main {
	public static void main(String args[]) {
		int serverNum1 = (args.length > 1) ? Integer.parseInt(args[0]) : 4;
		int serverNum2 = (args.length > 1) ? Integer.parseInt(args[1]) : 6;
		
		System.out.println("Trying to connect to camera argus-" + serverNum1);
		System.out.println("Trying to connect to camera argus-" + serverNum2);
                String[] address = new String[2];
                address[0] = "argus-" + serverNum1;
                address[1] = "argus-" + serverNum2;
		MainClientThread mthread = new MainClientThread(address, new int[]{serverNum1 + 4030, serverNum2 + 4030});
		mthread.run();
	}
}
