package client;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class WriteThread extends Thread {
    private static final byte[] CRLF = { 13, 10 };
    private Socket socket;
    private OutputStream os;
    private ClientStateMonitor stateMonitor;

    public WriteThread(Socket socket, ClientStateMonitor stateMonitor) {
        this.socket = socket;
        this.stateMonitor = stateMonitor;
    }

    public void run() {
        try {
            os = socket.getOutputStream();
            int mode = ClientStateMonitor.AUTO;
            while(true) {
                mode = stateMonitor.getModeBlocking(mode);
                System.out.println("Mode: " + mode);
                switch (mode) {
                    case ClientStateMonitor.AUTO:
                        sendIdleCommand();
                        break;
                    case ClientStateMonitor.MOVIE:
                        sendMovieCommand();
                        break;
                    case ClientStateMonitor.IDLE:
                        sendIdleCommand();
                        break;
                    default:
                        System.out.println("Weird mode");
                        break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void sendIdleCommand() {
        char c = 3;
        String s = "" + c;
        try {
            putLine(os, s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMovieCommand() {
        char c = 2;
        String s = "" + c;
        try {
            putLine(os, s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private static void putLine(OutputStream s, String str) throws IOException {
        s.write(str.getBytes());
        s.write(CRLF);
    }

}
