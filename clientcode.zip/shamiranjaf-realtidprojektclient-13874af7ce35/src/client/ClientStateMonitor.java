package client;

import GUI.GUI;

public class ClientStateMonitor {
	private int mode;
        private	GUI gui;
        private	MainClientThread thread;
	public static final int AUTO = 0;
	public static final int IDLE = 100;
	public static final int MOVIE = 200;//these have nothing to do with what we sen to the socket
        
	public ClientStateMonitor(MainClientThread thread) {
            this.thread = thread;
	}

	public synchronized void setMode(int mode, int whoSetMovie) {
		if (this.mode != mode) {
                    if(mode == MOVIE) {
			if (gui == null) gui = thread.getGUI();
			gui.setMovieMode();
                    }
                    gui.setWhoSetMovie(whoSetMovie);
		}
		this.mode = mode;
		System.out.println(mode);

		notifyAll();
	}

	public synchronized int getModeBlocking(int lastmode) {
		while (lastmode == mode) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return mode;
	}

	public synchronized int getMode() {
		return mode;
	}
}
