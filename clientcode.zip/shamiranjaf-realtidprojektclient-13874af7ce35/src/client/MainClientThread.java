package client;

import java.io.IOException;
import java.net.Socket;

import GUI.GUI;

public class MainClientThread extends Thread {
        private class ServerConnection {
            ReadThread readThread;
            WriteThread writeThread;
            public ServerConnection(Socket socket, BufferMonitor bm, int cameraId, ClientStateMonitor sm) {
		readThread = new ReadThread(socket, bm, cameraId, sm);
		writeThread = new WriteThread(socket, sm);
            }
            public void start() {
		writeThread.start();
		readThread.start();
            }
        }

	private BufferMonitor bufferMonitor;
	private ClientStateMonitor stateMonitor;
	private GUI gui;

	public void run() {
		System.out.println("Hello");

		int delay = 500;
		long lastImageTimeStamp = 0;
		System.out.println("Entering run loop...");
		while (true) {
			ImageWrapper imageWrapper = bufferMonitor.requestImage();
			if (imageWrapper != null) {
				gui.refreshImage(imageWrapper);
			}
		}

	}
	
	public GUI getGUI() {
		return gui;
	}

	public MainClientThread(String[] address, int port[]) {
		bufferMonitor = new BufferMonitor();
		stateMonitor = new ClientStateMonitor(this);
		gui = new GUI(stateMonitor);
                ServerConnection[] servers = new ServerConnection[address.length];
                for(int i = 0; i<address.length; i++) {
		    try {
                        servers[i] = new ServerConnection(new Socket(address[i], port[i]),bufferMonitor, i+1, stateMonitor);
                    } catch(IOException e) {
                        e.printStackTrace();
                    }
                }
                for(int i = 0; i<address.length; i++) {
                    servers[i].start();
                }
	}

}
