package client;

public class ImageWrapper {
    private long size;
    private long timeStamp;
    private byte[] imageData;
    private int cameraId;

    public ImageWrapper(long size, long timeStamp, byte[] imageData, int cameraId) {
        this.size = size;
        this.imageData = imageData;
        this.cameraId = cameraId;
        // Convert time from nanoseconds to milliseconds
        this.timeStamp = timeStamp;
    }

    public long getSize() {
        return size;
    }

    /* Timestamp converted from nanoseconds to milliseconds and returned */
    public long getTimeStamp() {
        // Date date = new Date(timeStamp / 1000000);
        // SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        // System.out.println("TIMESTAMP testimage" + format.format(date));
        // System.out.println("TIMESTAMP testimage (long) :" + timeStamp /
        // 1000000);
        // System.out.println("TIMESTAMP system (long) :" +
        // System.currentTimeMillis());

        return timeStamp;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public int getCameraId() {
        return cameraId;
    }

}
