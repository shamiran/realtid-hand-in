package client;

public class BufferMonitor {
    private ImageBuffer buffer1;
    private ImageBuffer buffer2;
    private int SYNC_DELAY = 500;
    private int ASYNC_DELAY = 200;
    private int CURR_DELAY = 500;
    private boolean SYNC = true;
    public BufferMonitor() {
        buffer1 = new ImageBuffer();
        buffer2 = new ImageBuffer();

    }

    synchronized void sendToBuffer(ImageWrapper image) {

        int cameraId = image.getCameraId();

        if (cameraId == 1) {
            buffer1.sendToBuffer(image);
        } else {
            buffer2.sendToBuffer(image);
        }
        notifyAll();

    }

    synchronized ImageWrapper requestImage() {
        //System.out.println("Enter requestImage");
        if(SYNC && CURR_DELAY != SYNC_DELAY) {
            CURR_DELAY += 50;
        }
        if(SYNC && (buffer1.getBufferSize() == 0 || buffer2.getBufferSize() == 0)) {
            SYNC = false;
            System.out.println("Switched to AsyncMode");
            CURR_DELAY = ASYNC_DELAY;
        } else if(!SYNC && buffer1.getBufferSize() > 2 && buffer2.getBufferSize() > 2){
            CURR_DELAY += 50;
            System.out.println("Switched to SyncMode");
            SYNC = true;
        }	

        while (buffer1.getBufferSize() == 0 && buffer2.getBufferSize() == 0) {
            try {
                //System.out.println("Waiting");
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //System.out.println("Passed wait");
        if (buffer1.getBufferSize() != 0 && buffer2.getBufferSize() == 0) {
            //System.out.println("Enter buffer1 loop");
            long timeDiff1 = systemImageTimeDifference(buffer1.getNextTimestamp());

            while (timeDiff1 > 0) {
                if (buffer2.getBufferSize() != 0) {
                    if (buffer2.getNextTimestamp() < buffer1.getNextTimestamp()) {
                        return null;
                    }
                }
                try {
                    //System.out.println(timeDiff1);
                    wait(timeDiff1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                timeDiff1 = systemImageTimeDifference(buffer1.getNextTimestamp());
            }
            return buffer1.requestImage();
        }

        if (buffer2.getBufferSize() != 0 && buffer1.getBufferSize() == 0) {
            long timeDiff2 = systemImageTimeDifference(buffer2.getNextTimestamp());

            while (timeDiff2 > 0) {
                if (buffer1.getBufferSize() != 0) {
                    if (buffer1.getNextTimestamp() < buffer2.getNextTimestamp()) {
                        return null;
                    }
                }
                try {
                    wait(timeDiff2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                timeDiff2 = systemImageTimeDifference(buffer2.getNextTimestamp());
            }
            return buffer2.requestImage();
        }


        if (buffer1.getNextTimestamp() < buffer2.getNextTimestamp()) {
            long timeDiff1 = systemImageTimeDifference(buffer1.getNextTimestamp());
            while (timeDiff1 > 0) {
                try {
                    wait(timeDiff1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                timeDiff1 = systemImageTimeDifference(buffer1.getNextTimestamp());
            }
            return buffer1.requestImage();
        } else {
            long timeDiff2 = systemImageTimeDifference(buffer2.getNextTimestamp());
            while (timeDiff2 > 0) {
                try {
                    wait(timeDiff2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                timeDiff2 = systemImageTimeDifference(buffer2.getNextTimestamp());
            }
            return buffer2.requestImage();
        }

    }

    private long systemImageTimeDifference(long timeStamp) {
        //System.out.println("image-timestamp: " + timeStamp);
        long currentTime = System.currentTimeMillis();
        //System.out.println("current-timestamp: " + currentTime);
        long timeDiff = timeStamp  + CURR_DELAY -  currentTime;
        //System.out.println("TimeDiff: " + timeDiff);
        return timeDiff;
    }

}
