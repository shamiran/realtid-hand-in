package client;

public class ImageBuffer {
    private ImageWrapper[] buffer;
    private int headIndex;
    private int tailIndex;
    private int bufferSize;
    private int bufferLength;

    public ImageBuffer() {
        bufferLength = 100;
        buffer = new ImageWrapper[bufferLength];

    }

    public void sendToBuffer(ImageWrapper image) {
        if (bufferSize >= bufferLength) {
            System.err.println("Buffer Full");
            return;
        }
        if (tailIndex == bufferLength - 1) {
            buffer[tailIndex] = image;
            tailIndex = 0;
        } else {
            buffer[tailIndex] = image;
            tailIndex++;
        }
        bufferSize++;
    }

    public int getBufferSize() {
        return bufferSize;
    }

    public long getNextTimestamp() {
        return buffer[headIndex].getTimeStamp();
    }

    public ImageWrapper requestImage() {
        if(bufferSize == 0) {
            System.err.println("tom buffer");
            return null;
        }
        ImageWrapper image = buffer[headIndex];
        buffer[headIndex++] = null;
        if (headIndex == bufferLength) {
            headIndex = 0;
        }
        bufferSize--;
        return image;

    }

}
