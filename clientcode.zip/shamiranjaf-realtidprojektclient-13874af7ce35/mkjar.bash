#!/bin/bash
mkdir -p bin &&\
javac -d bin -cp jar/camera.jar src/**/*.java &&\
cd bin &&\
jar cfm ../jar/client.jar ../Manifest.txt **/*.class &&\
cd ..
