#!/bin/bash
#./build.bash #&&\
echo hi
tmux new-window yes #"./send-server.bash $1" 
tmux split-window -v yes #"./send-server.bash $2"
tmux select-layout tiled > /dev/null
tmux select-pane -t 0
tmux set-window-option synchronize-panes on > /dev/null
