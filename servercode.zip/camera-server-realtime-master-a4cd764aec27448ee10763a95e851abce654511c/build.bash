#!/bin/bash
make clean &&\
make distclean &&\
make all
