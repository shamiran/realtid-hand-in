#!/bin/bash
make -f Makefile.fake clean &&\
make -f Makefile.fake &&\
./fake_server
