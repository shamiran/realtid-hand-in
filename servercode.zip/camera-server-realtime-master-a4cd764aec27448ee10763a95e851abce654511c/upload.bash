#!/bin/bash
./build.bash &&\
./send-server.bash $1
