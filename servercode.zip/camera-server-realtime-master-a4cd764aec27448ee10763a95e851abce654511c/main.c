#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>  // for memcpy, memset, strlen
#include <poll.h>
#include <pthread.h>
#include "camera.h"
#include <sys/time.h>
#include <time.h>
#include <signal.h>

#define DEBUG
#define MOVIE_WAIT 40000000LL
#define IDLE_WAIT 5000000000LL

// Remember to use the mutex
struct global_state {
    int movie;
    int listenfd;
    struct pollfd pfd;
    int connfd;
    int socket_open;
};

pthread_mutex_t global_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t global_cond = PTHREAD_COND_INITIALIZER;

void signal_callback_handler(int signum){
    printf("Caught signal SIGPIPE %d\n",signum);
}

int set_movie(struct global_state* gstate, int new_movie) {
    pthread_mutex_lock(&global_mutex);
    gstate->movie = new_movie;
    pthread_mutex_unlock(&global_mutex);
    pthread_cond_signal(&global_cond);
    return 0;
}

int get_movie(struct global_state* gstate) {
    pthread_mutex_lock(&global_mutex);
    int ret = gstate->movie;
    pthread_mutex_unlock(&global_mutex);
    return ret;
}

//clock_gettime() returns timespec 
long long time_since(struct timespec* last_sent) {
    struct timespec t;
    clock_gettime(CLOCK_REALTIME, &t);
    return (t.tv_sec - last_sent->tv_sec)*1000000000LL + t.tv_nsec - last_sent->tv_nsec;
}

void build_packet(unsigned char* out_array, capture_time stime, byte* byte_array, size_t size) {
    struct timespec time;
    clock_gettime(CLOCK_REALTIME, &time);
    stime = time.tv_sec*1000000000LL + time.tv_nsec;
    out_array[0] = (char)1;
    out_array[1] = size>>24;
    out_array[2] = size>>16;
    out_array[3] = size>>8;
    out_array[4] = size;
    int i = 5;	
    printf("time: %llu", stime); 
    out_array[i++] = ((stime & 0xff00000000000000LL)>>56);
    out_array[i++] = ((stime & 0x00ff000000000000LL)>>48);
    out_array[i++] = ((stime & 0x0000ff0000000000LL)>>40);
    out_array[i++] = ((stime & 0x000000ff00000000LL)>>32);
    out_array[i++] = ((stime & 0x00000000ff000000LL)>>24);
    out_array[i++] = ((stime & 0x0000000000ff0000LL)>>16);
    out_array[i++] = ((stime & 0x000000000000ff00LL)>>8);
    out_array[i++] = ((stime & 0x00000000000000ffLL));
    for(i = 0; i<size; i++){
        out_array[i+13] = (unsigned char)byte_array[i];
    }
}

int write_chars_to_socket(struct global_state* gstate, unsigned char* to_write, size_t size) {
    pthread_mutex_lock(&global_mutex);
    int connfd = gstate->connfd;
    pthread_mutex_unlock(&global_mutex);
    int ret = write(connfd, to_write, size);
    if(ret == -1) {
        perror("write");
        return errno;
    }
    return 0;
}

void write_img_to_socket(camera* camera, struct global_state* gstate, unsigned char* out_array) {
    frame* frame = camera_get_frame(camera);
    byte* byte_array = get_frame_bytes(frame);
    size_t size = get_frame_size(frame); //size of imgdata
    capture_time stime = get_frame_timestamp(frame);
    
    build_packet(out_array, stime, byte_array, size);
    write_chars_to_socket(gstate, out_array, size+13); //size+13 = size of contents in out_arr
    if(get_frame_motion(frame) && get_movie(gstate) == 0) {
        unsigned char cmd[1];
        cmd[0] = (char)2;
        write_chars_to_socket(gstate, cmd, 1);
    }
    //printf("Motion: %d\n",get_frame_motion(frame));
}


// Largely c&p from the example
int create_socket(struct global_state* state) {
    int reuse;
    state->listenfd = socket(AF_INET, SOCK_STREAM, 0);

    if(state->listenfd < 0) {
        perror("socket");
        return errno;
    }

    reuse = 1;
    setsockopt(state->listenfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    return 0;
}

int bind_and_listen(struct global_state* state, int port) {
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port);

    if(bind(state->listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr))) {
        perror("bind");
        return errno;
    }

    if(listen(state->listenfd, 10)) {
        perror("listen");
        return errno;
    }
    return 0;
}

int get_socket_open(struct global_state* gstate) {
    int open;
    pthread_mutex_lock(&global_mutex);
    open = gstate->socket_open;
    pthread_mutex_unlock(&global_mutex);
    return open;
}

void set_socket_open(struct global_state* gstate, int new) {
    pthread_mutex_lock(&global_mutex);
    gstate->socket_open = new;
    pthread_mutex_unlock(&global_mutex);
    pthread_cond_signal(&global_cond);
}

void read_socket(struct global_state* gstate) {
    unsigned char buf[1];

    while(get_socket_open(gstate)) {
        // read input
        int res = read(gstate->connfd, buf, 1);
        if(res==0) {
            set_socket_open(gstate, 0); 
        } else {
         //   printf("%c",buf[0]);
            if(buf[0] == 2 || buf[0] == '2') { //change to movie mode
                set_movie(gstate, 1);
            } else if(buf[0] == 3 || buf[0] == '3') { //change to idle mode
                set_movie(gstate, 0);
            }
        }
        //TODO: set socket open 0 sometime
    }
}

void* write_thread(void* in) {
    printf("We crated the thread!\n");
    struct global_state* gstate = (struct global_state*) in;
    struct timespec last_sent;
    camera* camera = camera_open();
    unsigned char* out_array = (unsigned char*) malloc(1024*1024); //might need to be changed.
    printf("On loop entry\n");
    int imgsent = 0;
    while(get_socket_open(gstate)) {
        //Send image
        clock_gettime(CLOCK_REALTIME, &last_sent);
        write_img_to_socket(camera, gstate, out_array);
        printf("wrote img: %d to socket\n",++imgsent);
        // Should not be set like this, time should be added if we are in the same mode.
        pthread_mutex_lock(&global_mutex);
        int movie = gstate->movie;
        long long diff = time_since(&last_sent);
        while((diff < MOVIE_WAIT && movie) || (movie == 0 && diff < IDLE_WAIT)){
            struct timespec wait_t;
            long long to_wait;
            if(movie) {
                to_wait = MOVIE_WAIT - diff;
            } else {
                to_wait = IDLE_WAIT - diff;
            }
            wait_t.tv_sec = to_wait/1000000000L;
            wait_t.tv_nsec = (to_wait%1000000000L);
            pthread_cond_timedwait(&global_cond, &global_mutex, &wait_t); 
            movie = gstate->movie;
            diff = time_since(&last_sent);
        }
        pthread_mutex_unlock(&global_mutex);
    }
    free(out_array);
    camera_close(camera);
    return NULL;
}

int main(int argc, char** argv) {
    /* Catch Signal Handler SIGPIPE */
    signal(SIGPIPE, signal_callback_handler);
    
    while(1) {
        struct global_state gstate;
        int port = atoi(argv[1]);
        printf("port: %d", port + 4030);
        create_socket(&gstate);
        bind_and_listen(&gstate, port + 4030);

        // We think this loop polls until the file descriptor opens
        // to then carry on.
        // We think it's trying to open the port.
        int ret;
        do {
            ret = poll(&(gstate.pfd), POLLIN, 2000);
            printf("poll returns %d\n", ret);
            printf("fd: %d\n", gstate.pfd.fd);
        } while(ret==0);

        gstate.connfd = accept(gstate.listenfd, (struct sockaddr*)NULL, NULL);
        set_socket_open(&gstate, 1);

        set_movie(&gstate,0);
        pthread_t write_t;
        printf("Creating write thread...\n");
        pthread_create(&write_t, NULL, write_thread, &gstate);	

        read_socket(&gstate);
        pthread_join(write_t,NULL);
        close(gstate.listenfd);
    }
    return 0;
}
