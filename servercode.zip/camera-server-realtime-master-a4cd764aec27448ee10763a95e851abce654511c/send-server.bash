#!/bin/bash
mv main nsa-server &&\
scp nsa-server rt@argus-$1.student.lth.se:~/ &&\
ssh rt@argus-$1
